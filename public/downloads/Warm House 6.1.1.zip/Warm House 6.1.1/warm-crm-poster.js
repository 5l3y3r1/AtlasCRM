/* warm-crm-poster.js  — worker-free cross-posting
 *
 * Re-implements the part that used to live on the licensed Cloudflare worker:
 * it scrapes the source listing, builds the normalised `data` object that the
 * extension's own fill scripts consume (qdr08sk7zg.js for myhome,
 * cr0aqvui6p.js for ss.ge), opens the target create page, injects that filler,
 * and sends it { action:"start", args:{ data, settings } }.
 *
 * The fillers and the background's `fetchImages` handler are reused as-is, so
 * no license key and no external server are involved.
 *
 * The fillers expect Georgian *label* strings (e.g. real_estate_type:"ბინა",
 * deal_type:"იყიდება"), so the transforms map myhome/ss ids → labels.
 */
(function () {
  'use strict';

  const CREATE_URL = {
    myhome: 'https://statements.myhome.ge/ka/statement/create?referrer=myhome&_gl=1',
    ss:     'https://home.ss.ge/ka/udzravi-qoneba/create?referrer=ssge',
  };
  const FILLER = { myhome: 'qdr08sk7zg.js', ss: 'cr0aqvui6p.js' };

  // ── myhome id → Georgian label maps ────────────────────────────────────
  const MH_RE_TYPE  = { 1: 'ბინა', 2: 'კერძო სახლი', 3: 'აგარაკი', 4: 'მიწის ნაკვეთი', 5: 'კომერციული ფართი', 7: 'სასტუმრო' };
  const MH_DEAL     = { 1: 'იყიდება', 2: 'ქირავდება', 3: 'გირავდება', 7: 'ქირავდება დღიურად' };
  const MH_STATUS   = { 1: 'ახალაშენებული', 2: 'ძველი აშენებული', 3: 'მშენებარე' };

  const S = (v) => (v == null || v === '') ? undefined : String(v);

  // ── source scrape (runs in the page) ───────────────────────────────────
  function scrapeInPage() {
    return (async () => {
      const url = location.href, host = location.host;
      const isSS = host.includes('ss.ge');
      let html;
      try { html = await fetch(url, { credentials: 'include' }).then(r => r.text()); }
      catch { const t = document.getElementById('__NEXT_DATA__'); html = t ? t.outerHTML : ''; }
      const m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
      if (!m) return { error: 'no __NEXT_DATA__ (open a listing detail page)' };
      let data; try { data = JSON.parse(m[1]); } catch { return { error: 'parse failed' }; }
      const pp = data?.props?.pageProps;
      if (isSS) {
        const raw = pp?.applicationData;
        return raw ? { site: 'ss', raw } : { error: 'ss applicationData not found' };
      }
      const raw = pp?.dehydratedState?.queries?.[0]?.state?.data?.data?.statement;
      return raw ? { site: 'myhome', raw } : { error: 'myhome statement not found' };
    })();
  }

  // ── transform: myhome statement → unified filler data ──────────────────
  function fromMyhome(it) {
    const p = it.price || {};
    const params = it.parameters ? Object.values(it.parameters).map(x => x?.display_name).filter(Boolean) : [];
    const imgs = Array.isArray(it.images) ? it.images.map(im => im?.large || im?.thumb || im?.url || im).filter(u => typeof u === 'string') : [];
    return {
      real_estate_type: MH_RE_TYPE[it.real_estate_type_id],
      deal_type:        MH_DEAL[it.deal_type_id],
      priceGEL:         p['1']?.price_total != null ? String(p['1'].price_total) : (it.currency_id === 1 ? S(it.total_price) : undefined),
      priceUSD:         p['2']?.price_total != null ? String(p['2'].price_total) : (it.currency_id === 2 ? S(it.total_price) : undefined),
      city_name:        S(it.city_name),
      address:          S(it.address),
      area:             S(it.area),
      rooms:            S(it.room_type_id),
      bedroom:          S(it.bedroom_type_id),
      bathroom:         S(it.bathroom_type_id),
      floor:            S(it.floor),
      total_floors:     S(it.total_floors),
      build_year:       S(it.build_year),
      height:           S(it.height),
      status:           MH_STATUS[it.status_id],
      condition:        S(it.condition),                 // already a label
      hot_water_type:   S(it.hot_water_type),             // already a label
      door_window_type: S(it.door_window_type),           // already a label
      living_room_type: S(it.living_room_type),
      living_room_area: S(it.living_room_area),
      storeroom_type:   S(it.storeroom_type),
      storeroom_area:   S(it.storeroom_area),
      swimming_pool_type: S(it.swimming_pool_type),
      balconies:        S(it.balconies),
      balcony_area:     S(it.balcony_area),
      porch_area:       S(it.porch_area),
      loggia_area:      S(it.loggia_area),
      waiting_space_area: S(it.waiting_space_area),
      yard_area:        S(it.yard_area),
      daily_rent_type:  S(it.daily_rent_type),
      add_info:         params,
      images:           imgs,
      description:      S(it.comment || it.additional_information),
    };
  }

  // ── transform: ss applicationData → unified filler data (best-effort) ───
  function fromSs(a) {
    const first = (...v) => v.find(x => x != null && x !== '');
    const SS_RE = { 1: 'ბინა', 2: 'კერძო სახლი', 3: 'აგარაკი', 4: 'მიწის ნაკვეთი', 5: 'კომერციული ფართი', 7: 'სასტუმრო' };
    const SS_DEAL = { 1: 'იყიდება', 2: 'ქირავდება', 3: 'გირავდება', 7: 'ქირავდება დღიურად' };
    // deep key-heuristic search (ss field names vary)
    const deep = (re, ok) => { let best, bd = 1e9; (function w(n, d) { if (!n || typeof n !== 'object' || d > 6) return; for (const [k, v] of Object.entries(n)) { if (v && typeof v === 'object') w(v, d + 1); else if (re.test(k) && (!ok || ok(v)) && d < bd && v !== '' && v != null) { best = v; bd = d; } } })(a, 0); return best; };
    const num = (v) => v != null && v !== '' && isFinite(Number(v));
    const imgs = Object.values(a.appImages || {}).map(im => (im && typeof im === 'object') ? (im.fileName || im.fileNameThumb) : im)
      .filter(u => typeof u === 'string').map(u => /^https?:\/\//.test(u) ? u : 'https://static.ss.ge/things/' + u);
    return {
      real_estate_type: SS_RE[first(a.realEstateTypeId, deep(/realestate.*id|estate_type/i, num))],
      deal_type:        SS_DEAL[first(a.dealTypeId, deep(/dealtype.*id|deal_type/i, num))],
      priceUSD:         S(first(a.priceUsd, a.price, deep(/price.*usd|^price$|total.*price/i, num))),
      city_name:        S(first(a.cityName, a.city, deep(/city.*name|^city$/i, v => typeof v === 'string'))),
      address:          S(first(a.address, a.streetAddress, deep(/address|street/i, v => typeof v === 'string'))),
      area:             S(first(a.area, a.totalArea, deep(/(^|_)area$|totalarea/i, num))),
      rooms:            S(first(a.rooms, a.roomTypeId, deep(/^rooms?$|roomtype/i, num))),
      bedroom:          S(first(a.bedrooms, a.bedroomTypeId, deep(/bedroom/i, num))),
      floor:            S(first(a.floor, deep(/^floor$|floornumber/i, num))),
      total_floors:     S(first(a.totalFloors, deep(/totalfloors|floors$/i, num))),
      build_year:       S(first(a.buildYear, deep(/build.*year/i, num))),
      add_info:         [],
      images:           imgs,
      description:      S(first(a.description, a.comment, deep(/description|comment|additional/i, v => typeof v === 'string' && v.length > 3))),
    };
  }

  function buildData(scr) {
    return scr.site === 'ss' ? fromSs(scr.raw) : fromMyhome(scr.raw);
  }

  // Default fill settings (mirrors the worker's `settings` object).
  const SETTINGS = {
    myhomeSettings: { currency: 'usd', description: 'Original - აღწერა', params: [], translate: false,
                      heating: 'skip', parking: 'skip', hot_water_type: 'skip', rent_type: 'skip', rent_period: 'skip' },
    ssgeSettings:   { currency: 'usd', description: 'Original - აღწერა', params: [], translate: false },
  };

  function status(msg, kind) {
    const el = document.getElementById('posterStatus');
    if (el) { el.textContent = msg || ''; el.className = 'crm-status' + (kind ? ' ' + kind : ''); }
  }

  // Robustly find the myhome/ss source tab. The popup's own window can shadow
  // lastFocusedWindow, so fall back through several queries.
  async function getSourceTab() {
    const ok = (t) => t && /(myhome\.ge|ss\.ge)/.test(t.url || '');
    let t = (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (ok(t)) return t;
    t = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (ok(t)) return t;
    const all = await chrome.tabs.query({ url: ['*://*.myhome.ge/*', '*://*.ss.ge/*'] });
    if (all.length) return all.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
    return null;
  }

  // Wait until a tab finishes loading. Guards the race where the load completes
  // before the listener attaches, and never hangs (8s cap).
  function waitTabComplete(tabId) {
    return new Promise((resolve) => {
      let done = false;
      const finish = () => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpd); setTimeout(resolve, 700); };
      const onUpd = (id, info) => { if (id === tabId && info.status === 'complete') finish(); };
      chrome.tabs.onUpdated.addListener(onUpd);
      chrome.tabs.get(tabId, (t) => { if (!chrome.runtime.lastError && t && t.status === 'complete') finish(); });
      setTimeout(finish, 8000);
    });
  }

  async function postToSite(target) {
    status('იკითხება განცხადება…', 'busy');
    const tab = await getSourceTab();
    if (!tab) { status('გახსენი myhome/ss.ge განცხადება და სცადე თავიდან', 'err'); return; }

    let scr;
    try {
      const [{ result } = {}] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scrapeInPage });
      scr = result;
    } catch (e) { status('წაკითხვა ვერ მოხერხდა: ' + e.message, 'err'); return; }
    if (!scr || scr.error) { status(scr?.error || 'მონაცემები ვერ მოიძებნა', 'err'); return; }

    const data = buildData(scr);
    if (!data.real_estate_type && !data.priceUSD && !data.priceGEL) { status('გადასატანი ვერ აეწყო (' + scr.site + ')', 'err'); return; }

    status('იხსნება ' + target + '-ის ფორმა…', 'busy');
    let created;
    try { created = await chrome.tabs.create({ url: CREATE_URL[target] }); }
    catch (e) { status('ფორმის გახსნა ვერ მოხერხდა: ' + e.message, 'err'); return; }
    await waitTabComplete(created.id);

    try {
      await chrome.scripting.executeScript({ target: { tabId: created.id }, files: [FILLER[target]] });
      await new Promise(r => setTimeout(r, 300)); // let the listener attach
      const resp = await chrome.tabs.sendMessage(created.id, { action: 'start', args: { data, settings: SETTINGS } });
      if (resp && resp.status === 'done') status('✓ ფორმა შეივსო ' + target + '-ზე', 'ok');
      else if (resp && resp.status === 'error') status('ფორმა შეივსო ნაწილობრივ — შეამოწმე ' + target, 'busy');
      else status('ფორმა გაიხსნა — ავსება მიმდინარეობს…', 'busy');
    } catch (e) {
      status('ავსება ვერ დაიწყო: ' + e.message + ' — დარწმუნდი რომ ' + target + '-ზე ხარ ავტორიზებული', 'err');
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('postMyhomeBtn')?.addEventListener('click', () => postToSite('myhome'));
    document.getElementById('postSsBtn')?.addEventListener('click', () => postToSite('ss'));
  });

  // expose for keyboard/other triggers if needed
  window.warmPostToSite = postToSite;
})();

// ===== WORKER-FREE TRANSFORMS (source listing -> filler propData) =====
var __MH_RE = {1:'ბინა',2:'კერძო სახლი',3:'აგარაკი',4:'მიწის ნაკვეთი',5:'კომერციული ფართი',7:'სასტუმრო'};
var __MH_DEAL = {1:'იყიდება',2:'ქირავდება',3:'გირავდება',7:'ქირავდება დღიურად'};
var __MH_STATUS = {1:'ახალაშენებული',2:'ძველი აშენებული',3:'მშენებარე'};
function __S(v){ return (v===undefined||v===null||v==='')?undefined:String(v); }
function __fromMyhome(it){
  var p = it.price || {};
  var params = it.parameters ? Object.values(it.parameters).map(function(x){return x&&x.display_name;}).filter(Boolean)
             : (it.cleanData && it.cleanData.add_info) || [];
  var imgs = Array.isArray(it.images) ? it.images.map(function(im){return (im&&(im.large||im.thumb||im.url))||im;}).filter(function(u){return typeof u==='string';})
           : ((it.cleanData && it.cleanData.images) || []);
  return {
    real_estate_type: __MH_RE[it.real_estate_type_id],
    deal_type: __MH_DEAL[it.deal_type_id],
    priceGEL: (p['1']&&p['1'].price_total!=null)?String(p['1'].price_total):(it.currency_id===1?__S(it.total_price):undefined),
    priceUSD: (p['2']&&p['2'].price_total!=null)?String(p['2'].price_total):(it.currency_id===2?__S(it.total_price):undefined),
    city_name: __S(it.city_name), address: __S(it.address), area: __S(it.area),
    rooms: __S(it.room_type_id), bedroom: __S(it.bedroom_type_id), bathroom: __S(it.bathroom_type_id),
    floor: __S(it.floor), total_floors: __S(it.total_floors), build_year: __S(it.build_year), height: __S(it.height),
    status: __MH_STATUS[it.status_id], condition: __S(it.condition),
    hot_water_type: __S(it.hot_water_type), door_window_type: __S(it.door_window_type),
    living_room_type: __S(it.living_room_type), living_room_area: __S(it.living_room_area),
    storeroom_type: __S(it.storeroom_type), storeroom_area: __S(it.storeroom_area),
    swimming_pool_type: __S(it.swimming_pool_type),
    balconies: __S(it.balconies), balcony_area: __S(it.balcony_area), porch_area: __S(it.porch_area),
    loggia_area: __S(it.loggia_area), waiting_space_area: __S(it.waiting_space_area), yard_area: __S(it.yard_area),
    daily_rent_type: __S(it.daily_rent_type),
    add_info: params, images: imgs,
    description: __S(it.comment || it.additional_information)
  };
}
function __fromSs(a){
  function first(){ for (var i=0;i<arguments.length;i++){ var v=arguments[i]; if(v!==undefined&&v!==null&&v!==''&&typeof v!=='object'&&typeof v!=='boolean') return v; } return undefined; }
  var SS_RE={1:'ბინა',2:'კერძო სახლი',3:'აგარაკი',4:'მიწის ნაკვეთი',5:'ბინა',7:'სასტუმრო'};
  var SS_DEAL={1:'იყიდება',2:'ქირავდება',3:'ქირავდება დღიურად',7:'ქირავდება დღიურად'};
  function deep(re, ok){ var best,bd=1e9; (function w(n,d){ if(!n||typeof n!=='object'||d>6) return; for(var k in n){ var v=n[k]; if(v&&typeof v==='object') w(v,d+1); else if(re.test(k)&&(!ok||ok(v))&&d<bd&&v!==''&&v!=null){best=v;bd=d;} } })(a,0); return best; }
  var num=function(v){ return v!=null&&v!==''&&isFinite(Number(v)); };
  var isStr=function(v){ return typeof v==='string'&&v.length>0; };
  // ss amenity booleans -> Georgian labels
  var AM={airConditioning:'კონდიციონერი',balcony:'აივანი',basement:'სარდაფი',cableTelevision:'საკაბელო ტელევიზია',drinkingWater:'სასმელი წყალი',electricity:'დენი',elevator:'ლიფტი',fridge:'მაცივარი',furniture:'ავეჯი',garage:'გარაჟი',glazedWindows:'მინა-პაკეტი',heating:'ცენტრალური გათბობა',hotWater:'ცხელი წყალი',internet:'ინტერნეტი',ironDoor:'რკინის კარი',naturalGas:'ბუნებრივი აირი',securityAlarm:'დაცვის სიგნალიზაცია',sewage:'კანალიზაცია',storage:'საკუჭნაო',telephone:'ტელეფონი',tv:'ტელევიზორი',washingMachine:'სარეცხი მანქანა',water:'წყალი',wiFi:'Wi-Fi',withPool:'აუზი',withBuiltInKitchen:'ჩაშენებული სამზარეულო'};
  var add_info=[]; for(var k in AM){ if(a[k]===true) add_info.push(AM[k]); }
  var imgs=Object.values(a.appImages||{}).map(function(im){return (im&&typeof im==='object')?(im.fileName||im.fileNameThumb):im;})
           .filter(function(u){return typeof u==='string';})
           .map(function(u){return /^https?:\/\//.test(u)?u:('https://static.ss.ge/things/'+u);});
  var price = deep(/price.*usd|usd.*price/i,num);
  if(price==null) price = deep(/^price$|price.*total|total.*price/i,num);
  return {
    // ss provides the Georgian labels directly — use them, map ids only as fallback
    real_estate_type: first(a.realEstateType) || SS_RE[a.realEstateTypeId],
    deal_type:        first(a.realEstateDealType) || SS_DEAL[a.realEstateDealTypeId],
    priceUSD:         __S(price),
    city_name:        __S(first(a.cityName, a.cityTitle, a.city, deep(/city.*name|city.*title|^city$/i,isStr))),
    address:          __S(first(a.address, a.streetAddress, deep(/street.*address|^address$/i,isStr))),
    area:             __S(first(a.totalArea, a.area, a.areaOfHouse)),
    rooms:            __S(a.rooms),
    bedroom:          __S(a.bedrooms),
    bathroom:         __S(a.toilet),
    floor:            __S(a.floor),
    total_floors:     __S(a.floors),
    status:           __S(a.realEstateStatus),
    condition:        __S(a.state),
    project:          __S(a.project),
    latitude:         __S(a.locationLatitude),
    longitude:        __S(a.locationLongitude),
    owner_name:       __S(a.contactPerson),
    owner_phone:      __S(first(a.phoneNumber, a.phone, a.userPhone, deep(/phone.*number|mobile/i,function(v){return typeof v==='string'&&/\d{5,}/.test(v);}))),
    // ss "other info" checkboxes the filler reads
    viewOnStreet:     a.viewOnStreet, viewOnYard: a.viewOnYard, brightPlace: a.light, cozyPlace: a.comfortable,
    daily_rent_type:  (a.realEstateDealTypeId===3||a.realEstateDealType==='ქირავდება დღიურად')?'ქირავდება დღიურად':undefined,
    add_info: add_info, images: imgs,
    description: __S(first(a.description, a.comment, a.metaDescription, deep(/description|comment/i,function(v){return typeof v==='string'&&v.length>10;})))
  };
}
try { chrome.storage.local.get(['apiKey'], function(r){ if(!r.apiKey) chrome.storage.local.set({apiKey:'local'}); }); } catch(e){}
// ===== END WORKER-FREE TRANSFORMS =====

async function getInjectionState() {
  const {
    injectionState: _0x318f42
  } = await chrome.storage.local.get("injectionState");
  return _0x318f42 ?? false;
}
async function setInjectionState(_0x3e1e8b) {
  await chrome.storage.local.set({
    injectionState: _0x3e1e8b
  });
}
function sendMessageTab(_0x309cdd) {
  chrome.tabs.sendMessage(_0x309cdd, {
    action: "start"
  }).then(_0x2215ee => {}).catch(_0x51e7a3 => {});
}
async function getCurrentTab() {
  const _0xe95ce8 = {
    active: true,
    lastFocusedWindow: true
  };
  const [_0x452453] = await chrome.tabs.query(_0xe95ce8);
  return _0x452453;
}
function getPathByUrl(_0x120bf4) {
  if (_0x120bf4) {
    if (_0x120bf4.includes("home.ss.ge")) {
      return "n9ykvyygh3.js";
    } else if (_0x120bf4.includes("myhome.ge")) {
      return "4v0ngwgqjd.js";
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function getFillByUrl(_0x1c8876) {
  if (_0x1c8876) {
    if (_0x1c8876.includes("home.ss.ge")) {
      return "cr0aqvui6p.js";
    } else if (_0x1c8876.includes("myhome.ge")) {
      return "qdr08sk7zg.js";
    } else {
      return null;
    }
  } else {
    return null;
  }
}
function injectFile(_0x49b470, _0x3eb6ac) {
  if (_0x3eb6ac) {
    chrome.scripting.executeScript({
      target: {
        tabId: _0x49b470
      },
      files: [_0x3eb6ac]
    }).catch(_0x34fa6d => {});
  }
}
async function setServerUiState(_0x490a8c) {
  await chrome.storage.local.set({
    serverUiState: _0x490a8c
  });
}
async function getServerUiState() {
  return (await chrome.storage.local.get("serverUiState")).serverUiState ?? false;
}
async function injectLoadingUiServer(_0x38d148) {
  try {
    if (await getServerUiState()) {
      return null;
    }
    await setServerUiState(true);
    injectFile(_0x38d148, "793nygsm1k.js");
    injectFile(_0x38d148, "j222ztk8g3.js");
  } catch {}
}
async function removeLoadingUiServer(_0x24d635) {
  if (_0x24d635) {
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId: _0x24d635
        },
        func: () => {
          const _0x1b1a2c = document.getElementById("my-shadow");
          if (_0x1b1a2c) {
            _0x1b1a2c.remove();
          }
        }
      });
    } catch {}
  }
}
function waitForData(_0x131607) {
  return new Promise((_0x49c880, _0x44dcd7) => {
    const _0x691a9a = Date.now() + 10000;
    const _0xa225c2 = _0x691a9a - 8000;
    let _0x418ab2 = false;
    let _0x277b16 = null;
    let _0x199607 = null;
    function _0x2d2b3d() {
      chrome.storage.onChanged.removeListener(_0xe5b46c);
      clearTimeout(_0x277b16);
      clearTimeout(_0x199607);
    }
    async function _0xe5b46c(_0x3edd02, _0x3084a2) {
      if (_0x3084a2 !== "local" || !("propDataReady" in _0x3edd02) || !_0x3edd02.propDataReady.newValue) {
        return;
      }
      _0x2d2b3d();
      await chrome.storage.local.remove("propDataReady");
      const {
        propData: _0x572644
      } = await chrome.storage.local.get("propData");
      if (_0x572644 && Object.keys(_0x572644).length > 0) {
        _0x49c880();
      } else {
        _0x44dcd7(new Error("no data"));
      }
    }
    chrome.storage.onChanged.addListener(_0xe5b46c);
    _0x277b16 = setTimeout(() => {
      _0x2d2b3d();
      _0x44dcd7(new Error("timeout waiting for data from content script"));
    }, 10000);
    const _0x2572a4 = _0xa225c2 - Date.now();
    _0x199607 = setTimeout(async () => {
      if (!_0x418ab2) {
        _0x418ab2 = true;
        const _0x3a9c17 = _0x691a9a - 10000;
        await chrome.storage.local.set({
          startTime: _0x3a9c17
        });
        await injectLoadingUiServer(_0x131607);
      }
    }, Math.max(0, _0x2572a4));
    chrome.storage.local.get(["propData", "propDataReady"]).then(async _0x407027 => {
      if (_0x407027.propDataReady) {
        _0x2d2b3d();
        await chrome.storage.local.remove("propDataReady");
        if (_0x407027.propData && Object.keys(_0x407027.propData).length > 0) {
          _0x49c880();
        } else {
          _0x44dcd7(new Error("no data in storage"));
        }
      }
    });
  });
}
const ERROR_MAPPINGS = {
  ORIGIN_DENIED: {
    header: "Access Denied",
    message: "ეს პროგრამა არ არის უფლებამოსილი სერვერის გამოყენებისთვის."
  },
  INVALID_LICENSE_KEY: {
    header: "Invalid License",
    message: "მითითებული ლიცენზირებული გასაღები არასწორია ან არ არსებობს."
  },
  LICENSE_EXPIRED: {
    header: "License Expired",
    message: "თქვენი სერვისის ვადა ამოწურულია. სერვისის სარგებლობის გასაგრძელებლად, გთხოვთ, გაანახლოთ. "
  },
  VERSION_NOT_SUPPORTED: {
    header: "Update Required",
    message: "პროგრამის ეს ვერსია აღარ არის ვალიდური, გთხოვთ, გაანახლოთ უახლეს ვერსიამდე."
  },
  DEVICE_LIMIT_REACHED: {
    header: "Device Limit",
    message: "თქვენ მიაღწიეთ ამ ლიცენზირებული გასაღების დაშვებული მოწყობილობების მაქსიმალურ რაოდენობას."
  },
  RATE_LIMIT_EXCEEDED: {
    header: "Too Many Requests",
    message: "შეანელეთ! თქვენ ძალიან ბევრ მოთხოვნას აგზავნით მოკლე დროში."
  },
  MISSING_KEY: {
    header: "Key Missing",
    message: "გთხოვთ შეიყვანოთ თქვენი ლიცენზირებული გასაღები პროგრამის პანელში."
  },
  FORBIDDEN_ADMIN_KEY: {
    header: "Admin Key Blocked",
    message: "ადმინისტრატორის გასაღების გამოყენება ამ პროგრამაში აკრძალულია."
  },
  FETCH_ERR: {
    header: "Network Error",
    message: "სერვერთან დაკავშირება ვერ მოხერხდა. გთხოვთ შეამოწმოთ ინტერნეტ კავშირი."
  }
};
async function injectErrorUi(_0x62c148, _0x1fdb7b, _0x4b183f, _0x2ad7f2) {
  try {
    _0x62c148 ||= (await getCurrentTab())?.id;
    if (!_0x62c148) {
      return;
    }
    let _0x105e2f = _0x1fdb7b;
    let _0x2c6b43 = _0x2ad7f2;
    let _0x293b75 = _0x4b183f;
    let _0x101a7f = "";
    let _0x3d964f = _0x4b183f;
    const _0x5bfb94 = _0x2ad7f2?.match(/(?:returned|status|code)\s*:?\s*(\d{3})/i) || _0x2ad7f2?.match(/\b(\d{3})\b/);
    if (_0x5bfb94) {
      _0x101a7f = _0x5bfb94[1];
    }
    if (_0x2ad7f2?.includes("{")) {
      try {
        const _0x3f1198 = _0x2ad7f2.substring(_0x2ad7f2.indexOf("{"));
        const _0x1adb11 = JSON.parse(_0x3f1198);
        if (_0x1adb11.error) {
          _0x3d964f = _0x1adb11.error;
        }
      } catch {}
    }
    const _0x481ab0 = ERROR_MAPPINGS[_0x3d964f];
    if (_0x481ab0) {
      _0x105e2f = _0x3d964f;
      _0x2c6b43 = _0x481ab0.message;
    } else if (_0x3d964f && _0x3d964f !== "ERROR") {
      _0x105e2f = _0x3d964f;
    }
    _0x293b75 = _0x101a7f || (_0x3d964f && _0x3d964f.length <= 6 ? _0x3d964f : "ERR");
    await chrome.storage.local.set({
      errorData: {
        header: _0x105e2f,
        code: _0x293b75,
        message: _0x2c6b43
      }
    });
    injectFile(_0x62c148, "fc2ov32sec.js");
  } catch {}
}
async function checkIfInvalid(_0x30b723) {
  const _0x4a43d0 = await chrome.storage.local.get(["propData"]);
  if (_0x4a43d0.propData?.error) {
    const _0x3ec8cc = _0x4a43d0.propData.error;
    await injectErrorUi(_0x30b723, "ERROR", "---", _0x3ec8cc);
    return false;
  }
  return true;
}
function getSettingByUrl(_0x233db7) {
  if (_0x233db7) {
    if (_0x233db7.includes("home.ss.ge")) {
      return "ssgeSettings";
    } else if (_0x233db7.includes("myhome.ge")) {
      return "myhomeSettings";
    } else {
      return null;
    }
  } else {
    return null;
  }
}
async function createNewTab(_0x758e05, _0x564767) {
  let _0x1877c4 = null;
  if (_0x758e05 === "myhome") {
    await chrome.storage.local.set({
      targetSite: "myhome"
    });
    _0x1877c4 = "https://statements.myhome.ge/ka/statement/create?referrer=myhome&_gl=1";
  } else {
    await chrome.storage.local.set({
      targetSite: "ssge"
    });
    _0x1877c4 = "https://home.ss.ge/ka/udzravi-qoneba/create?referrer=ssge";
  }
  if (!_0x1877c4) {
    return null;
  }
  const _0xa43fd6 = getFillByUrl(_0x1877c4);
  const _0xfed4a2 = getSettingByUrl(_0x1877c4);
  try {
    await waitForData(_0x564767);
    if (!(await checkIfInvalid(_0x564767))) {
      return null;
    }
    const {
      propData: _0x4b5690
    } = await chrome.storage.local.get(["propData"]);
    const _0xcd99c9 = await chrome.storage.local.get([_0xfed4a2]);
    await new Promise((_0x4bbd1e, _0x1429b4) => {
      let _0x368aa7;
      const _0x1a0ab1 = setTimeout(() => {
        if (_0x368aa7) {
          chrome.tabs.onUpdated.removeListener(_0x368aa7);
        }
        _0x1429b4(new Error("Tab creation/loading timeout for " + _0x1877c4));
      }, 20000);
      chrome.tabs.create({
        url: _0x1877c4
      }, _0x342917 => {
        if (chrome.runtime.lastError) {
          clearTimeout(_0x1a0ab1);
          _0x1429b4(new Error(chrome.runtime.lastError.message));
          return;
        }
        _0x368aa7 = async function (_0x3378ff, _0x3d5912) {
          if (_0x3378ff === _0x342917.id && _0x3d5912.status === "complete") {
            chrome.tabs.onUpdated.removeListener(_0x368aa7);
            clearTimeout(_0x1a0ab1);
            try {
              await chrome.scripting.executeScript({
                target: {
                  tabId: _0x342917.id
                },
                files: [_0xa43fd6]
              });
              const _0x5b1895 = await chrome.tabs.sendMessage(_0x342917.id, {
                action: "start",
                args: {
                  data: _0x4b5690,
                  settings: _0xcd99c9
                }
              });
              try { console.log('[warm] filler(' + _0xa43fd6 + ') response:', _0x5b1895, '| propData present:', !!_0x4b5690, '| create url:', _0x1877c4); } catch (e) {}
              _0x4bbd1e(_0x5b1895);
            } catch (_0x4fc328) {
              _0x1429b4(_0x4fc328);
            }
          }
        };
        chrome.tabs.onUpdated.addListener(_0x368aa7);
      });
    });
  } catch {
    return null;
  } finally {
    await setServerUiState(false);
    await removeLoadingUiServer(_0x564767);
  }
  if (await checkIfInvalid(_0x564767)) {
    return true;
  } else {
    return null;
  }
}
function getKey() {
  return new Promise(_0x117bf9 => {
    chrome.storage.local.get(["apiKey"], _0x2d6e9c => {
      _0x117bf9(_0x2d6e9c.apiKey);
    });
  });
}
async function handleInjectionForActiveTab(_0x2fd464) {
  if (!(await getInjectionState())) {
    await setInjectionState(true);
    try {
      const _0x24ef3d = await getCurrentTab();
      if (!_0x24ef3d) {
        throw new Error("Could not find active tab");
      }
      await chrome.storage.local.remove(["propData", "propDataReady"]);
      const _0x43f1a1 = _0x24ef3d.id;
      const _0x381fed = _0x24ef3d.url;
      const _0x517bc7 = getPathByUrl(_0x381fed);
      if (_0x517bc7) {
        injectFile(_0x43f1a1, _0x517bc7);
      } else {
        throw new Error("Unsupported site for injection: " + (_0x381fed || "unknown URL"));
      }
      await createNewTab(_0x2fd464, _0x43f1a1);
      await chrome.storage.local.remove("propData");
    } catch {} finally {
      await setInjectionState(false);
      const _0x1cffd3 = await getCurrentTab();
      if (_0x1cffd3) {
        await removeLoadingUiServer(_0x1cffd3.id);
      }
    }
  }
}
async function openAndFillTab(_0xb5cd11) {
  let _0x58c612 = "";
  let _0x51caea = "";
  if (_0xb5cd11 === "myhome") {
    _0x58c612 = "https://statements.myhome.ge/ka/statement/create?referrer=myhome&_gl=1";
    _0x51caea = "myhomeSettings";
  } else {
    _0x58c612 = "https://home.ss.ge/ka/udzravi-qoneba/create?referrer=ssge";
    _0x51caea = "ssgeSettings";
  }
  const _0x59895e = getFillByUrl(_0x58c612);
  const {
    propData: _0x30a8a9
  } = await chrome.storage.local.get(["propData"]);
  const _0x578f6e = await chrome.storage.local.get([_0x51caea]);
  return new Promise((_0x3ad491, _0x3f3fd3) => {
    let _0x372d4d;
    const _0x2dd4f0 = setTimeout(() => {
      if (_0x372d4d) {
        chrome.tabs.onUpdated.removeListener(_0x372d4d);
      }
      _0x3f3fd3(new Error("openAndFillTab timeout for " + _0xb5cd11));
    }, 20000);
    chrome.tabs.create({
      url: _0x58c612
    }, _0x565275 => {
      _0x372d4d = function (_0x2ead0a, _0x3f3116) {
        if (_0x2ead0a === _0x565275.id && _0x3f3116.status === "complete") {
          chrome.tabs.onUpdated.removeListener(_0x372d4d);
          clearTimeout(_0x2dd4f0);
          chrome.scripting.executeScript({
            target: {
              tabId: _0x565275.id
            },
            files: [_0x59895e]
          }).then(() => {
            chrome.tabs.sendMessage(_0x565275.id, {
              action: "start",
              args: {
                data: _0x30a8a9,
                settings: _0x578f6e
              }
            });
            _0x3ad491();
          }).catch(_0x3f3fd3);
        }
      };
      chrome.tabs.onUpdated.addListener(_0x372d4d);
    });
  });
}
async function callBothFills() {
  if (await getInjectionState()) {
    return;
  }
  await setInjectionState(true);
  let _0x44f524 = null;
  try {
    const _0x30e3c5 = await getCurrentTab();
    if (!_0x30e3c5) {
      throw new Error("Could not find active tab");
    }
    _0x44f524 = _0x30e3c5.id;
    await chrome.storage.local.remove(["propData", "propDataReady"]);
    const _0x594c15 = getPathByUrl(_0x30e3c5.url);
    if (_0x594c15) {
      injectFile(_0x30e3c5.id, _0x594c15);
    } else {
      throw new Error("Unsupported site for double inject: " + (_0x30e3c5.url || "unknown"));
    }
    await waitForData(_0x30e3c5.id);
    if (!(await checkIfInvalid(_0x30e3c5.id))) {
      return;
    }
    await Promise.allSettled([openAndFillTab("myhome"), openAndFillTab("ssge")]);
    await chrome.storage.local.remove("propData");
  } catch {} finally {
    await setInjectionState(false);
    if (_0x44f524) {
      await removeLoadingUiServer(_0x44f524);
    }
  }
}
async function urlToObject(_0x382096) {
  const _0x490dc3 = [];
  if (!_0x382096) {
    return _0x490dc3;
  }
  let _0x5ba53f = 0;
  for (const _0x2cbc8a of _0x382096) {
    _0x5ba53f++;
    try {
      const _0x4f443b = await fetch(_0x2cbc8a);
      if (!_0x4f443b.ok) {
        continue;
      }
      let _0x2ec65c = await _0x4f443b.blob();
      try {
        const _0x58c188 = await createImageBitmap(_0x2ec65c);
        const _0x35df19 = new OffscreenCanvas(_0x58c188.width, _0x58c188.height);
        const _0x2a73b2 = _0x35df19.getContext("2d");
        _0x2a73b2.fillStyle = "#ffffff";
        _0x2a73b2.fillRect(0, 0, _0x35df19.width, _0x35df19.height);
        _0x2a73b2.drawImage(_0x58c188, 0, 0);
        _0x2ec65c = await _0x35df19.convertToBlob({
          type: "image/jpeg",
          quality: 0.95
        });
      } catch {}
      let _0x3b8a92;
      if (typeof FileReader !== "undefined") {
        _0x3b8a92 = await new Promise((_0x4e0cc3, _0x3d029c) => {
          const _0x5a60b9 = new FileReader();
          _0x5a60b9.onloadend = () => {
            const _0x46e49d = _0x5a60b9.result;
            _0x4e0cc3(_0x46e49d.includes(",") ? _0x46e49d.split(",")[1] : _0x46e49d);
          };
          _0x5a60b9.onerror = _0x3d029c;
          _0x5a60b9.readAsDataURL(_0x2ec65c);
        });
      } else {
        const _0x496247 = await _0x2ec65c.arrayBuffer();
        const _0x204639 = new Uint8Array(_0x496247);
        let _0x337cf7 = "";
        const _0x592d23 = 8192;
        for (let _0x3dc856 = 0; _0x3dc856 < _0x204639.length; _0x3dc856 += _0x592d23) {
          _0x337cf7 += String.fromCharCode(..._0x204639.subarray(_0x3dc856, _0x3dc856 + _0x592d23));
        }
        _0x3b8a92 = btoa(_0x337cf7);
      }
      const _0x300487 = Date.now();
      const _0x27fcd4 = _0x2ec65c.type && _0x2ec65c.type.startsWith("image/") ? _0x2ec65c.type : "image/jpeg";
      let _0x5193e3 = "jpg";
      if (_0x27fcd4 === "image/png") {
        _0x5193e3 = "png";
      } else if (_0x27fcd4 === "image/webp") {
        _0x5193e3 = "webp";
      } else if (_0x27fcd4 === "image/jpeg") {
        _0x5193e3 = "jpg";
      }
      _0x490dc3.push({
        data: _0x3b8a92,
        name: "image_" + _0x300487 + "_" + _0x5ba53f + "." + _0x5193e3,
        type: _0x27fcd4
      });
    } catch {
      continue;
    }
  }
  return _0x490dc3;
}
async function saveData(_0x47cd8c) {
  await chrome.storage.local.set({
    propData: _0x47cd8c,
    propDataReady: true
  });
}
async function callServer(rawData, direction, action, key, fingerprint, version) {
  // WORKER-FREE: reproduce the worker's only job (source listing -> propData) locally.
  if (action === "validate") {
    return { valid: true, status: "ok", active: true, isValid: true, plan: "local", message: "ok" };
  }
  try {
    const isSs = !!(rawData && (rawData.applicationId !== undefined || rawData.appImages !== undefined || rawData.application !== undefined));
    const data = isSs ? __fromSs(rawData) : __fromMyhome(rawData);
    try { console.log('[warm] built propData', { isSs, direction, type: data.real_estate_type, deal: data.deal_type, price: data.priceUSD || data.priceGEL, city: data.city_name, rooms: data.rooms, images: (data.images || []).length }); } catch (e) {}
    return data;
  } catch (e) {
    console.warn('[warm] transform failed', e);
    return { error: "local transform failed: " + (e && e.message ? e.message : e) };
  }
}
async function callTransform(_0x387931) {
  return (await chrome.storage.local.get(["targetSite"])).targetSite !== _0x387931;
}
async function getFingerprint() {
  let {
    hwid: _0x520757
  } = await chrome.storage.local.get("hwid");
  if (!_0x520757) {
    _0x520757 = crypto.randomUUID();
    await chrome.storage.local.set({
      hwid: _0x520757
    });
  }
  const _0x4ba8c = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(_0x520757 + navigator.userAgent));
  const _0x3c498f = [...new Uint8Array(_0x4ba8c)].map(_0x38e198 => _0x38e198.toString(16).padStart(2, "0")).join("");
  await chrome.storage.local.set({
    fingerprint: _0x3c498f
  });
  return _0x3c498f;
}
function getManifestVersion() {
  return chrome.runtime.getManifest().version;
}
async function handlePropData({
  destination: _0x49c55a,
  data: _0x3b9f98
}, _0x488caf = null) {
  try {
    const _0x3bb524 = await getKey();
    const _0x4d08b1 = (await callTransform(_0x49c55a)) ? "transform" : "getData";
    const _0x1a20e5 = getManifestVersion();
    const _0x2b54a2 = await getFingerprint();
    const _0x16485b = await callServer(_0x3b9f98, _0x49c55a, _0x4d08b1, _0x3bb524, _0x2b54a2, _0x1a20e5);
    if (_0x16485b) {
      await saveData({
        ..._0x16485b
      });
    } else {
      throw new Error("Empty response from server");
    }
  } catch (_0x25880e) {
    await saveData({
      error: _0x25880e.message
    });
    throw _0x25880e;
  }
}
async function injectImageDownloader() {
  if (!(await getInjectionState())) {
    await setInjectionState(true);
    try {
      const _0x51e2d0 = await getCurrentTab();
      if (!_0x51e2d0) {
        throw new Error("No active tab found for image injection");
      }
      const _0x253f31 = _0x51e2d0.id;
      const _0x5d3ece = _0x51e2d0.url;
      const _0x54af54 = getPathByUrl(_0x5d3ece);
      if (_0x54af54) {
        injectFile(_0x253f31, _0x54af54);
        await waitForData(_0x253f31);
      }
      injectFile(_0x253f31, "mxu16lnp5l.js");
    } catch {} finally {
      await setInjectionState(false);
    }
  }
}
async function downloadImages(_0x4b74d8, _0xfbee2f, _0x34b417 = null) {
  for (const [_0x23a4b6, _0x1f2381] of _0x4b74d8.entries()) {
    const _0x23a567 = _0x1f2381.split(".").pop().split("?")[0];
    const _0x3ffb58 = _0x34b417 !== null ? _0x34b417 + _0x23a4b6 : _0x23a4b6 + 1;
    chrome.downloads.download({
      url: _0x1f2381,
      filename: _0xfbee2f + "/image_" + _0x3ffb58 + "." + _0x23a567
    });
  }
}
async function fetchPropertyData(_0x79588c, _0x1f25df) {
  const _0x17143e = _0x1f25df ? "https://home.ss.ge/ka/udzravi-qoneba/a-" + _0x79588c : "https://www.myhome.ge/pr/" + _0x79588c;
  const _0x4f0914 = (await (await fetch(_0x17143e)).text()).match(/<script id="__NEXT_DATA__"[^>]*>(.*?)<\/script>/s);
  if (!_0x4f0914) {
    throw new Error("Could not find __NEXT_DATA__");
  }
  const _0x4b4a38 = JSON.parse(_0x4f0914[1]);
  if (_0x1f25df) {
    return _0x4b4a38?.props?.pageProps?.applicationData ?? null;
  } else {
    return _0x4b4a38?.props?.pageProps?.dehydratedState?.queries?.[0]?.state?.data?.data?.statement ?? null;
  }
}
function extractCleanData(_0x5794c4, _0x2755ba, _0x276aa5) {
  if (_0x276aa5) {
    let _0x36b1fe = "fileName";
    if (_0x2755ba?.quality === "Original") {
      _0x36b1fe = "fileNameThumb";
    }
    const _0x36e484 = [];
    const _0x381735 = {
      airConditioning: "კონდიციონერი",
      balcony: "აივანი",
      basement: "სარდაფი",
      elevator: "ლიფტი",
      fridge: "მაცივარი",
      furniture: "ავეჯი",
      garage: "გარაჟი",
      heating: "ცენტ. გათბობა",
      lastFloor: "ბოლო სართული",
      hotWater: "ცხელი წყალი",
      internet: "ინტერნეტი",
      naturalGas: "ბუნებრივი აირი",
      tv: "ტელევიზორი",
      washingMachine: "სარეცხი მანქანა",
      isPetFriendly: "დასაშვებია შინაური ცხოველები",
      isForUkraine: "შეღავათი უკრაინის მოქ.",
      drinkingWater: "სასმელი წყალი",
      withPool: "აუზი",
      electricity: "ელ. ენერგია",
      sewage: "კანალიზაცია",
      water: "წყალი",
      wiFi: "Wi-Fi",
      withBuiltInKitchen: "ჩაშენებული სამზარეულო",
      cableTelevision: "საკაბელო ტელევიზია",
      glazedWindows: "მინა-პაკეტი",
      ironDoor: "რკინის კარი",
      securityAlarm: "სიგნალიზაცია",
      storage: "სათავსო",
      telephone: "ტელეფონი"
    };
    for (const [_0x548211, _0x5baa3a] of Object.entries(_0x381735)) {
      if (_0x5794c4[_0x548211] === true) {
        _0x36e484.push(_0x5baa3a);
      }
    }
    return {
      id: _0x5794c4.applicationId,
      images: Object.values(_0x5794c4.appImages ?? {}).map(_0x240b09 => _0x240b09[_0x36b1fe]),
      add_info: _0x36e484
    };
  } else {
    let _0x5c6912 = "large";
    if (_0x2755ba?.quality === "Original") {
      _0x5c6912 = "thumb";
    }
    return {
      id: _0x5794c4.id,
      images: Object.values(_0x5794c4.images ?? {}).map(_0x173216 => _0x173216[_0x5c6912]),
      add_info: Object.values(_0x5794c4.parameters ?? {}).map(_0x3ecdeb => _0x3ecdeb.display_name)
    };
  }
}
function handleMessages(_0x32c9ad, _0x150885, _0x13e3a4) {
  if (_0x150885.id !== chrome.runtime.id) {
    return false;
  }
  if (_0x32c9ad.action === "photoInjection") {
    injectImageDownloader();
    return false;
  }
  if (_0x32c9ad.action === "download-images") {
    downloadImages(_0x32c9ad.payload.images, _0x32c9ad.payload.id, _0x32c9ad.payload.startIndex);
    return false;
  }
  if (_0x32c9ad.action === "reuploadFromId") {
    const {
      id: _0x5cdb94,
      isSS: _0x2969e2,
      authName: _0x312890
    } = _0x32c9ad.payload;
    const _0x14fdd0 = _0x2969e2 ? "ssge" : "myhome";
    (async () => {
      try {
        await chrome.storage.local.set({
          targetSite: _0x14fdd0
        });
        const _0x24e77b = await fetchPropertyData(_0x5cdb94, _0x2969e2);
        if (!_0x24e77b) {
          throw new Error("Failed to fetch property data");
        }
        const _0x361a09 = await chrome.storage.local.get(["photoSettings"]);
        const _0x5374b3 = {
          ..._0x24e77b,
          cleanData: extractCleanData(_0x24e77b, _0x361a09?.photoSettings, _0x2969e2),
          authName: _0x312890,
          is_owner: true,
          prop_link: _0x2969e2 ? "https://home.ss.ge/ka/udzravi-qoneba/a-" + _0x5cdb94 : "https://www.myhome.ge/pr/" + _0x5cdb94
        };
        await handlePropData({
          destination: _0x14fdd0,
          data: _0x5374b3
        }, _0x150885.tab.id);
        await openAndFillTab(_0x14fdd0);
        _0x13e3a4({
          status: "ok"
        });
      } catch (_0x563bcd) {
        await injectErrorUi(_0x150885.tab.id, "Reupload Error", "REUPLOAD_ERR", _0x563bcd.message);
        _0x13e3a4({
          error: _0x563bcd.message
        });
      }
    })();
    return true;
  }
  if (_0x32c9ad.action === "reupload") {
    handlePropData(_0x32c9ad.payload, _0x150885.tab.id).then(() => openAndFillTab(_0x32c9ad.payload.destination)).then(() => _0x13e3a4({
      status: "ok"
    })).catch(async _0xb50115 => {
      await injectErrorUi(_0x150885.tab.id, "Server Error", "FETCH_ERR", _0xb50115.message);
      _0x13e3a4({
        error: _0xb50115.message
      });
    });
    return true;
  } else if (_0x32c9ad.action === "injection") {
    handleInjectionForActiveTab(_0x32c9ad.payload).then(() => _0x13e3a4({
      status: "ok"
    })).catch(_0xdb4011 => _0x13e3a4({
      error: _0xdb4011.message
    }));
    return true;
  } else if (_0x32c9ad.action === "doubleInject") {
    callBothFills().then(() => _0x13e3a4({
      status: "ok"
    })).catch(_0x1b82e0 => _0x13e3a4({
      error: _0x1b82e0.message
    }));
    return true;
  } else if (_0x32c9ad.action === "propData") {
    handlePropData(_0x32c9ad.payload, _0x150885.tab.id).then(() => _0x13e3a4({
      status: "ok"
    })).catch(_0x1e7122 => {
      _0x13e3a4({
        error: _0x1e7122.message
      });
    });
    return true;
  } else if (_0x32c9ad.action === "validateKey") {
    (async () => {
      try {
        const _0x375009 = await getKey();
        const _0x3748b6 = await getFingerprint();
        const _0x4f1b11 = getManifestVersion();
        const _0xa7a8f6 = await callServer({}, "myhome", "validate", _0x375009, _0x3748b6, _0x4f1b11);
        _0x13e3a4({
          status: "ok",
          data: _0xa7a8f6
        });
      } catch (_0x53f595) {
        _0x13e3a4({
          error: _0x53f595.message
        });
      }
    })();
    return true;
  } else {
    if (_0x32c9ad.call === "fetchImages") {
      urlToObject(_0x32c9ad.urls).then(_0x5c1d8d => {
        _0x13e3a4({
          images: _0x5c1d8d
        });
      }).catch(_0x4a1a46 => {
        _0x13e3a4({
          error: _0x4a1a46.message
        });
      });
    }
    return true;
  }
}
chrome.commands.onCommand.addListener(_0x471241 => {
  switch (_0x471241) {
    case "mhge":
      handleInjectionForActiveTab("myhome");
      break;
    case "ssge":
      handleInjectionForActiveTab("ssge");
      break;
    case "both":
      callBothFills();
      break;
    case "photos":
      injectImageDownloader();
      break;
    default:
      break;
  }
});
chrome.runtime.onMessage.addListener(handleMessages);
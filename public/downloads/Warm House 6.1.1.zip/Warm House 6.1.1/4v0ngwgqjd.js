(async () => {
  function buildClean(st, ps) {
    const q = (ps && ps.quality === "Original") ? "thumb" : "large";
    return {
      id: st.id,
      images: Object.values(st.images || {}).map(function (x) { return x[q]; }),
      add_info: Object.values(st.parameters || {}).map(function (x) { return x.display_name; })
    };
  }
  function authName() {
    const e = document.querySelector('[alt="auth-user"]');
    const n = e && e.nextElementSibling;
    return n ? n.textContent : null;
  }
  // Resilient: known path first, then any query, then a deep search for a
  // statement-like object. Survives myhome moving things around in __NEXT_DATA__.
  function findStatement(pp) {
    if (!pp) return null;
    let s = pp.dehydratedState && pp.dehydratedState.queries && pp.dehydratedState.queries[0]
          && pp.dehydratedState.queries[0].state && pp.dehydratedState.queries[0].state.data
          && pp.dehydratedState.queries[0].state.data.data
          && pp.dehydratedState.queries[0].state.data.data.statement;
    if (s) return s;
    const qs = (pp.dehydratedState && pp.dehydratedState.queries) || [];
    for (let i = 0; i < qs.length; i++) {
      const d = qs[i] && qs[i].state && qs[i].state.data;
      const c = (d && d.data && d.data.statement) || (d && d.statement);
      if (c) return c;
    }
    let found = null;
    (function walk(n, depth) {
      if (found || !n || typeof n !== "object" || depth > 9) return;
      if (!Array.isArray(n) && n.id !== undefined &&
          (n.real_estate_type_id !== undefined || (n.price && typeof n.price === "object"))) {
        found = n; return;
      }
      const vals = Array.isArray(n) ? n : Object.values(n);
      for (let i = 0; i < vals.length; i++) {
        const v = vals[i];
        if (v && typeof v === "object") walk(v, depth + 1);
      }
    })(pp, 0);
    return found;
  }
  async function getStatement() {
    let html = "";
    try { html = await fetch(location.href).then(function (r) { return r.text(); }); } catch (e) {}
    const m = html && html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    let json = null;
    if (m) { try { json = JSON.parse(m[1]); } catch (e) {} }
    if (!json) {
      const el = document.getElementById("__NEXT_DATA__");
      if (el) { try { json = JSON.parse(el.textContent); } catch (e) {} }
    }
    return json ? findStatement(json.props && json.props.pageProps) : null;
  }
  const ps = await chrome.storage.local.get(["photoSettings"]);
  let st = null;
  try { st = await getStatement(); } catch (e) { st = null; }
  if (!st) {
    await chrome.storage.local.set({ propData: null, propDataReady: true });
    return null;
  }
  const data = Object.assign({}, st, {
    cleanData: buildClean(st, ps && ps.photoSettings),
    authName: authName(),
    prop_link: location.href
  });
  chrome.runtime.sendMessage({ action: "propData", payload: { destination: "myhome", data: data } });
})();

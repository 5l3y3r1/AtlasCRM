/* warm-crm-bridge.js
 * Adds "Send to CRM" to the Warm House popup. Self-contained — does not touch
 * the extension's background worker. It re-fetches the active listing page
 * (the same approach the built-in scrapers use, which survives in-page SPA
 * navigation) and POSTs the listing to the CRM's /api/import/ingest.
 */
(function () {
  'use strict';

  // ─────────────────────────────────────────────────────────────────────
  //  ADMIN CONFIG — set these ONCE, then every agent's copy just works.
  //  Agents never see or type anything. Leave blank to fall back to the
  //  manual gear settings (useful only while setting up).
  //    url : your CRM address on Railway, e.g. https://warm-ge.up.railway.app
  //    key : the same value you set for CRM_INGEST_KEY on Railway
  // ─────────────────────────────────────────────────────────────────────
  // Per-user isolation: the extension authenticates as the agent's OWN logged-in
  // CRM session (sent as a cookie on the credentialed fetch below). We deliberately
  // do NOT bake a shared key — that would attribute every agent's imports to one
  // account. Each agent must be logged into the CRM in this browser.
  const CRM_CONFIG = {
    url: "https://realestatecrm-production-06e8.up.railway.app",
    key: ""   // leave blank — session auth provides per-agent isolation
  };
  const CONFIGURED = !!CRM_CONFIG.url;

  const STORE = { url: 'crmBaseUrl', key: 'crmIngestKey' };
  const $ = (id) => document.getElementById(id);
  const trimSlash = (u) => {
    let v = String(u || '').trim().replace(/\/+$/, '');
    if (v && !/^https?:\/\//i.test(v)) v = 'https://' + v;
    return v;
  };

  document.addEventListener('DOMContentLoaded', init);

  async function init() {
    const sendBtn = $('sendToCrmButton');
    if (!sendBtn) return;

    // Baked-in config wins. Seed storage and hide the settings from agents.
    if (CONFIGURED) {
      await chrome.storage.local.set({ [STORE.url]: trimSlash(CRM_CONFIG.url), [STORE.key]: (CRM_CONFIG.key || '').trim() });
      $('crmSettingsBtn')?.remove();
      $('crmSettingsPanel')?.remove();
    } else {
      const cfg = await chrome.storage.local.get([STORE.url, STORE.key]);
      if ($('crm-url-input')) $('crm-url-input').value = cfg[STORE.url] || '';
      if ($('crm-key-input')) $('crm-key-input').value = cfg[STORE.key] || '';
      $('crmSettingsBtn')?.addEventListener('click', (e) => {
        e.stopPropagation();
        $('crmSettingsPanel')?.classList.toggle('hide');
      });
      $('crm-save')?.addEventListener('click', async () => {
        const url = trimSlash($('crm-url-input').value);
        const key = $('crm-key-input').value.trim();
        await chrome.storage.local.set({ [STORE.url]: url, [STORE.key]: key });
        const b = $('crm-save'); const prev = b.textContent;
        b.textContent = '✓'; setTimeout(() => (b.textContent = prev), 1000);
        $('crmSettingsPanel')?.classList.add('hide');
        setStatus('', '');
      });
    }

    sendBtn.addEventListener('click', sendToCrm);
  }

  function setStatus(msg, kind) {
    const el = $('crmStatus');
    if (!el) return;
    el.textContent = msg || '';
    el.className = 'crm-status' + (kind ? ' ' + kind : '');
  }
  function busy(on) {
    $('sendToCrmButton')?.closest('.crm-item')?.classList.toggle('busy', !!on);
  }

  async function sendToCrm() {
    const cfg = await chrome.storage.local.get([STORE.url, STORE.key]);
    const base = trimSlash(CONFIGURED ? CRM_CONFIG.url : cfg[STORE.url]);
    const key = ((CONFIGURED ? CRM_CONFIG.key : cfg[STORE.key]) || '').trim();

    if (!base) {
      if (!CONFIGURED) { $('crmSettingsPanel')?.classList.remove('hide'); setStatus('First fill in CRM URL and Key', 'err'); }
      else setStatus('CRM არაა კონფიგურირებული', 'err');
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab || !tab.url || !/(myhome\.ge|ss\.ge)/.test(tab.url)) {
      setStatus('Open a myhome.ge or ss.ge listing page', 'err');
      return;
    }

    busy(true);
    setStatus('Reading the listing…', 'busy');

    let scraped;
    try {
      const [{ result } = {}] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: extractFromPage,
      });
      scraped = result;
    } catch (e) {
      busy(false);
      setStatus('Could not read page: ' + e.message, 'err');
      return;
    }

    if (!scraped || scraped.error || !scraped.raw) {
      busy(false);
      setStatus(scraped?.error || 'Listing data not found on this page', 'err');
      return;
    }

    setStatus('Sending to CRM…', 'busy');
    const endpoint = base + '/api/import/ingest';
    try {
      const r = await fetch(endpoint, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, key ? { 'X-CRM-Key': key } : {}),
        credentials: 'include',
        body: JSON.stringify({ source: scraped.source, url: scraped.url, raw: scraped.raw }),
      });

      const text = await r.text();
      let j = null;
      try { j = JSON.parse(text); } catch { /* non-JSON body */ }

      // Non-2xx → surface the real status + message.
      if (!r.ok) {
        if (r.status === 401 || r.status === 403) {
          setStatus('გაიარე ავტორიზაცია CRM-ში ამ ბრაუზერში, შემდეგ სცადე თავიდან', 'err');
        } else {
          const msg = (j && j.error) ? j.error : (text ? text.slice(0, 120) : '');
          setStatus('CRM error ' + r.status + (msg ? ': ' + msg : ''), 'err');
        }
        console.warn('[warm-crm] POST', endpoint, '→', r.status, text);
        return;
      }

      // 200 but not the JSON we expect → wrong URL or stale deployment.
      if (!j || !j.data || !j.data.id) {
        setStatus('CRM replied 200 but no listing was created — check the CRM URL and that the latest server is deployed', 'err');
        console.warn('[warm-crm] unexpected 200 body from', endpoint, ':', text.slice(0, 300));
        return;
      }

      const d = j.data;
      if (d.target !== 'listing') {
        // Created, but on an older endpoint that stages to AI-Hunter imports.
        setStatus('⚠ Saved to AI-Hunter Imports, not Properties — your CRM is running an OLD import.js. id=' + d.id, 'err');
        console.warn('[warm-crm] old endpoint response:', d);
        return;
      }

      const label = d.listing_number ? ' ' + d.listing_number : '';
      setStatus('✓ Added to Properties' + label + ' (' + (d.photos ?? 0) + ' photos)', 'ok');
      console.log('[warm-crm] created listing', d.id, d.listing_number || '(no number)');
    } catch (e) {
      // Network/CORS/DNS failures land here.
      setStatus('Could not reach CRM: ' + e.message + ' — check the URL', 'err');
      console.error('[warm-crm] fetch failed to', endpoint, e);
    } finally {
      busy(false);
    }
  }

  /* Runs in the page context. Re-fetches the current URL's HTML (fresh
     server-rendered __NEXT_DATA__, not the possibly-stale live DOM copy) and
     pulls out the listing object. Returns { source, url, raw } | { error }. */
  async function extractFromPage() {
    const url = location.href;
    const host = location.host;
    const isSS = host.includes('ss.ge');

    function getNextData(html) {
      const m = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
      if (!m) return null;
      try { return JSON.parse(m[1]); } catch { return null; }
    }
    function deepFind(node, pred, depth) {
      depth = depth || 0;
      if (!node || depth > 9 || typeof node !== 'object') return null;
      if (pred(node)) return node;
      const vals = Array.isArray(node) ? node : Object.values(node);
      for (const v of vals) {
        if (v && typeof v === 'object') {
          const hit = deepFind(v, pred, depth + 1);
          if (hit) return hit;
        }
      }
      return null;
    }

    try {
      let html;
      try {
        html = await fetch(url, { credentials: 'include' }).then((r) => r.text());
      } catch {
        const tag = document.getElementById('__NEXT_DATA__');
        html = tag ? '<script id="__NEXT_DATA__">' + tag.textContent + '</script>' : '';
      }
      const data = getNextData(html);
      if (!data) return { error: 'Page data not found — open the listing detail page and try again' };
      const pp = data?.props?.pageProps;

      if (isSS) {
        let raw = pp?.applicationData
          ?? deepFind(pp, (o) => !Array.isArray(o) && 'applicationId' in o && 'appImages' in o);
        return raw ? { source: 'ss', url, raw }
                   : { error: 'ss.ge listing data not found — open a property page (…/udzravi-qoneba/…)' };
      }

      // myhome
      let raw = pp?.dehydratedState?.queries?.[0]?.state?.data?.data?.statement
             ?? pp?.statement?.data?.statement
             ?? deepFind(pp, (o) => !Array.isArray(o) && o.price && typeof o.price === 'object'
                                    && ('real_estate_type_id' in o || 'deal_type_id' in o));
      return raw ? { source: 'myhome', url, raw }
                 : { error: 'myhome listing data not found — open a listing page (…/pr/…)' };
    } catch (e) {
      return { error: 'parse failed: ' + e.message };
    }
  }
})();
